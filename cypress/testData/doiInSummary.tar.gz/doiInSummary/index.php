<?php

/**
 * Copyright (c) 2015-2023 Lepidus Tecnologia
 * Distributed under the GNU GPL v3. For full terms see LICENSE or https://www.gnu.org/licenses/gpl-3.0.txt.
 */

require_once('DoiInSummaryPlugin.inc.php');

return new DoiInSummaryPlugin();
